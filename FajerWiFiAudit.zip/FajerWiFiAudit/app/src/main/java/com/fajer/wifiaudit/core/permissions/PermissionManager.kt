package com.fajer.wifiaudit.core.permissions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.provider.Settings
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat

/**
 * Wraps the permission story that changed shape across Android releases:
 *
 * - Android 12 and below: [Manifest.permission.ACCESS_FINE_LOCATION] plus device location
 *   services switched on.
 * - Android 13+ (API 33): apps can instead request
 *   [Manifest.permission.NEARBY_WIFI_DEVICES] with `neverForLocation`, which does not require
 *   location services to be on at all.
 *
 * We request both permissions in the manifest and let this class decide, at runtime, which
 * one actually satisfies the current OS version — so the rest of the app never has to think
 * about API levels.
 */
object PermissionManager {

    fun requiredScanPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    /** What to pass to the system permission dialog. Android 12 requires FINE and COARSE to be
     *  requested together, so below API 33 both are included. */
    fun permissionsToRequest(): Array<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
        } else {
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
            )
        }

    fun hasScanPermission(context: Context): Boolean =
        requiredScanPermissions().all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }

    /** Location services must be ON in addition to the permission below API 33. */
    fun isLocationServicesRequired(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU

    fun isLocationServicesEnabled(context: Context): Boolean = try {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        locationManager != null && LocationManagerCompat.isLocationEnabled(locationManager)
    } catch (_: Exception) {
        false
    }

    /** Opens the system Location screen so the user can switch location services on. */
    fun locationSettingsIntent(): Intent =
        Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Opens the Wi-Fi quick panel on API 29+, or the full Wi-Fi settings on older versions. */
    fun wifiSettingsIntent(): Intent =
        Intent(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Settings.Panel.ACTION_WIFI
            else Settings.ACTION_WIFI_SETTINGS
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Opens this app's page in system Settings (for when a permission was permanently denied). */
    fun appSettingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(android.net.Uri.fromParts("package", context.packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun isWifiHardwareSupported(context: Context): Boolean =
        context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_WIFI)

    fun isWifiEnabled(context: Context): Boolean = try {
        val wifiManager = context.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as? WifiManager
        wifiManager?.isWifiEnabled == true
    } catch (_: Exception) {
        false
    }

    fun currentState(context: Context): PermissionState = PermissionState(
        hasScanPermission = hasScanPermission(context),
        locationServicesRequired = isLocationServicesRequired(),
        isLocationServicesEnabled = isLocationServicesEnabled(context),
        isWifiEnabled = isWifiEnabled(context),
        isWifiHardwareSupported = isWifiHardwareSupported(context)
    )
}
