package com.fajer.wifiaudit.core.permissions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.wifi.WifiManager
import android.provider.Settings
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat

/**
 * Wraps the permission story that changed shape across Android releases:
 *
 * - Android 12 and below: [Manifest.permission.ACCESS_FINE_LOCATION] plus device location
 *   services switched on.
 * - Android 13+ (API 33): apps can instead request
 *   [Manifest.permission.NEARBY_WIFI_DEVICES] with `neverForLocation`, which does not require
 *   location services to be on at all.
 *
 * We request both permissions in the manifest and let this class decide, at runtime, which
 * one actually satisfies the current OS version — so the rest of the app never has to think
 * about API levels.
 */
object PermissionManager {

    fun hasNearbyWifiPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.NEARBY_WIFI_DEVICES) ==
            PackageManager.PERMISSION_GRANTED

    fun hasFineLocationPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    /**
     * What to pass to the system permission dialog. Android 12 needs FINE and COARSE requested
     * together; Android 13+ additionally has NEARBY_WIFI_DEVICES. Many phones (Xiaomi and other
     * OEM builds in particular) still return an empty scan list unless the Location permission is
     * granted too, so on every version we ask for the full set.
     */
    fun permissionsToRequest(): Array<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                Manifest.permission.NEARBY_WIFI_DEVICES,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
            )
        } else {
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
            )
        }

    /** Either permission is enough for the scan to be *attempted*; see the empty-result hint for the rest. */
    fun hasScanPermission(context: Context): Boolean =
        hasNearbyWifiPermission(context) || hasFineLocationPermission(context)

    /**
     * Location services must be ON on every Android version. Stock Android 13+ can scan without
     * them, but OEM builds commonly return an empty list, which looks like "scanning does nothing".
     * Requiring it makes the app say so, with a button to the right Settings page.
     */
    fun isLocationServicesRequired(): Boolean = true

    fun isLocationServicesEnabled(context: Context): Boolean = try {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        locationManager != null && LocationManagerCompat.isLocationEnabled(locationManager)
    } catch (_: Exception) {
        false
    }

    /** Opens the system Location screen so the user can switch location services on. */
    fun locationSettingsIntent(): Intent =
        Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Opens the Wi-Fi quick panel on API 29+, or the full Wi-Fi settings on older versions. */
    fun wifiSettingsIntent(): Intent =
        Intent(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) Settings.Panel.ACTION_WIFI
            else Settings.ACTION_WIFI_SETTINGS
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Opens this app's page in system Settings (for when a permission was permanently denied). */
    fun appSettingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(android.net.Uri.fromParts("package", context.packageName, null))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun isWifiHardwareSupported(context: Context): Boolean =
        context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_WIFI)

    fun isWifiEnabled(context: Context): Boolean = try {
        val wifiManager = context.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as? WifiManager
        wifiManager?.isWifiEnabled == true
    } catch (_: Exception) {
        false
    }

    fun currentState(context: Context): PermissionState = PermissionState(
        hasScanPermission = hasScanPermission(context),
        locationServicesRequired = isLocationServicesRequired(),
        isLocationServicesEnabled = isLocationServicesEnabled(context),
        isWifiEnabled = isWifiEnabled(context),
        isWifiHardwareSupported = isWifiHardwareSupported(context)
    )
}
