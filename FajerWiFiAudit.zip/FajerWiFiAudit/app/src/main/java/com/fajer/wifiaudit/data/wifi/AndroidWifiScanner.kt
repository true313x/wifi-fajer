package com.fajer.wifiaudit.data.wifi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.fajer.wifiaudit.R
import com.fajer.wifiaudit.core.common.AppResult
import com.fajer.wifiaudit.core.permissions.PermissionManager
import com.fajer.wifiaudit.core.utils.SecurityClassifier
import com.fajer.wifiaudit.domain.model.WifiNetwork
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Thin wrapper around [WifiManager]. This is the *only* file in the app that calls a Wi-Fi
 * scanning API — everything else works with [WifiNetwork], the plain data class above it.
 *
 * What this class does NOT do, by design: request a connection, supply a password to
 * [WifiManager] or [android.net.wifi.WifiNetworkSuggestion], or attempt authentication of any
 * kind. It only reads [android.net.wifi.ScanResult]s the platform already collected.
 */
class AndroidWifiScanner(private val context: Context) {

    private val wifiManager: WifiManager? by lazy {
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    }

    suspend fun scan(): AppResult<List<WifiNetwork>> {
        val manager = wifiManager
            ?: return AppResult.Error("This device has no Wi-Fi adapter")

        if (!PermissionManager.hasScanPermission(context)) {
            return AppResult.Error("Wi-Fi scan permission is not granted")
        }
        if (!manager.isWifiEnabled) {
            return AppResult.Error("Wi-Fi is turned off. Turn it on, then scan again.")
        }
        if (PermissionManager.isLocationServicesRequired() &&
            !PermissionManager.isLocationServicesEnabled(context)
        ) {
            return AppResult.Error("Turn on Location services: Android returns no Wi-Fi results while it is off.")
        }

        // Ask the platform for a fresh scan and wait (briefly) for it. If Android throttles the
        // request (a few scans per 2 minutes), we fall back to the latest cached results below.
        val scanAccepted = requestScanAndWait(manager, timeoutMs = 6_000)

        return try {
            @Suppress("MissingPermission") // Verified above via PermissionManager.
            val results = manager.scanResults.orEmpty()
            val networks = results
                .distinctBy { it.BSSID }
                .map { result ->
                    WifiNetwork(
                        ssid = result.SSID.orEmpty(),
                        bssid = result.BSSID.orEmpty(),
                        rssiDbm = result.level,
                        frequencyMhz = result.frequency,
                        capabilities = result.capabilities.orEmpty(),
                        securityType = SecurityClassifier.classify(result.capabilities.orEmpty()),
                        wifiStandard = wifiStandardLabel(result),
                        lastSeenEpochMillis = System.currentTimeMillis(),
                    )
                }
                .sortedByDescending { it.rssiDbm }
            if (networks.isEmpty()) AppResult.Error(emptyResultsMessage(scanAccepted))
            else AppResult.Success(networks)
        } catch (e: SecurityException) {
            AppResult.Error("Permission was revoked while scanning", e)
        }
    }

    private fun requestScan(manager: WifiManager): Boolean = try {
        @Suppress("DEPRECATION", "MissingPermission")
        manager.startScan()
    } catch (_: SecurityException) {
        false
    }

    /**
     * The receiver is registered BEFORE the scan is requested, so a fast result can't be missed,
     * and it is always unregistered afterwards (the old version leaked it on success).
     */
    private suspend fun requestScanAndWait(manager: WifiManager, timeoutMs: Long): Boolean {
        val done = CompletableDeferred<Unit>()
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                done.complete(Unit)
            }
        }
        ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        try {
            val accepted = requestScan(manager)
            if (accepted) withTimeoutOrNull(timeoutMs) { done.await() }
            return accepted
        } finally {
            runCatching { context.unregisterReceiver(receiver) }
        }
    }

    /** Explains an empty result and appends the facts a bug report needs (no guessing). */
    private fun emptyResultsMessage(scanAccepted: Boolean): String {
        fun yn(value: Boolean) = if (value) "yes" else "no"
        val details = "[Android ${Build.VERSION.SDK_INT} · ${Build.MANUFACTURER} · " +
            "startScan=${yn(scanAccepted)} · " +
            "location=${yn(PermissionManager.isLocationServicesEnabled(context))} · " +
            "nearby=${yn(PermissionManager.hasNearbyWifiPermission(context))} · " +
            "fine=${yn(PermissionManager.hasFineLocationPermission(context))}]"
        return context.getString(R.string.scan_no_results_hint) + "\n\n" + details
    }

    /** Best-effort label — [android.net.wifi.ScanResult] only exposes this from API 30+. */
    private fun wifiStandardLabel(result: android.net.wifi.ScanResult): String? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        return try {
            when (result.wifiStandard) {
                4 -> "802.11n (Wi-Fi 4)"
                5 -> "802.11ac (Wi-Fi 5)"
                6 -> "802.11ax (Wi-Fi 6)"
                8 -> "802.11be (Wi-Fi 7)"
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    /** Currently associated network, read via ConnectivityManager capabilities where possible. */
    fun observeConnectivity() = callbackFlow<Boolean> {
        val manager = wifiManager
        trySend(manager?.isWifiEnabled == true)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                trySend(wifiManager?.isWifiEnabled == true)
            }
        }
        ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(WifiManager.WIFI_STATE_CHANGED_ACTION),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        awaitClose { runCatching { context.unregisterReceiver(receiver) } }
    }
}
