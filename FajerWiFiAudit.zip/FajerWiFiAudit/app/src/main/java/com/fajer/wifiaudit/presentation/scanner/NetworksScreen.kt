package com.fajer.wifiaudit.presentation.scanner

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.NavHostController
import com.fajer.wifiaudit.R
import com.fajer.wifiaudit.core.permissions.PermissionManager
import com.fajer.wifiaudit.core.ui.components.EmptyState
import com.fajer.wifiaudit.core.ui.components.SecurityBadge
import com.fajer.wifiaudit.core.ui.components.SignalIndicator
import com.fajer.wifiaudit.domain.model.WifiNetwork
import com.fajer.wifiaudit.presentation.common.currentAppContainer
import com.fajer.wifiaudit.presentation.navigation.FajerRoute

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworksScreen(navController: NavHostController) {
    val container = currentAppContainer()
    val viewModel: NetworkListViewModel = viewModel(
        factory = viewModelFactory { initializer { NetworkListViewModel(container.wifiRepository) } }
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    val context = LocalContext.current
    var permissionDenied by remember { mutableStateOf(false) }
    val p = state.permissionState

    fun openSettings(intent: Intent) {
        runCatching { context.startActivity(intent) }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.refreshPermissions()
        val granted = PermissionManager.hasScanPermission(context)
        permissionDenied = !granted
        if (granted) viewModel.scan()
    }

    // Re-check permission / Wi-Fi / Location whenever the user comes back (e.g. from Settings).
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.refreshPermissions() }

    // Scan automatically as soon as everything a scan needs is in place.
    LaunchedEffect(p.canScan) {
        if (p.canScan) viewModel.scan()
    }

    // One handler for the toolbar button AND every empty-state button: it fixes whatever is
    // missing first (permission, Wi-Fi, Location) and only then scans.
    val onScanClick: () -> Unit = {
        when {
            !p.hasScanPermission ->
                if (permissionDenied) openSettings(PermissionManager.appSettingsIntent(context))
                else permissionLauncher.launch(PermissionManager.permissionsToRequest())
            !p.isWifiEnabled -> openSettings(PermissionManager.wifiSettingsIntent())
            p.locationServicesRequired && !p.isLocationServicesEnabled ->
                openSettings(PermissionManager.locationSettingsIntent())
            else -> viewModel.scan()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.networks_title)) },
                actions = {
                    IconButton(onClick = onScanClick, enabled = !state.isScanning) {
                        Icon(Icons.Default.Refresh, contentDescription = stringResource(R.string.networks_scan))
                    }
                },
            )
        },
    ) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            when {
                !p.hasScanPermission -> {
                    EmptyState(
                        title = stringResource(R.string.permission_rationale_title),
                        body = stringResource(
                            if (permissionDenied) R.string.permission_denied_body
                            else R.string.permission_rationale_body
                        ),
                        actionLabel = stringResource(
                            if (permissionDenied) R.string.networks_action_open_app_settings
                            else R.string.permission_grant
                        ),
                        onAction = onScanClick,
                        modifier = Modifier.fillMaxSize(),
                    )
                }

                !p.isWifiEnabled -> {
                    EmptyState(
                        title = stringResource(R.string.networks_wifi_off_title),
                        body = stringResource(R.string.networks_wifi_off_body),
                        actionLabel = stringResource(R.string.networks_action_open_wifi_settings),
                        onAction = onScanClick,
                        modifier = Modifier.fillMaxSize(),
                    )
                }

                p.locationServicesRequired && !p.isLocationServicesEnabled -> {
                    EmptyState(
                        title = stringResource(R.string.networks_location_off_title),
                        body = stringResource(R.string.networks_location_off_body),
                        actionLabel = stringResource(R.string.networks_action_open_location_settings),
                        onAction = onScanClick,
                        modifier = Modifier.fillMaxSize(),
                    )
                }

                state.isScanning && state.networks.isEmpty() -> {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        CircularProgressIndicator()
                        Text(
                            text = stringResource(R.string.networks_scanning),
                            modifier = Modifier.padding(top = 12.dp),
                        )
                    }
                }

                state.networks.isEmpty() -> {
                    EmptyState(
                        title = stringResource(R.string.networks_empty_title),
                        body = state.errorMessage ?: stringResource(R.string.networks_empty_body),
                        actionLabel = stringResource(R.string.networks_empty_action),
                        onAction = onScanClick,
                        modifier = Modifier.fillMaxSize(),
                    )
                }

                else -> {
                    if (state.isScanning) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                    state.errorMessage?.let { message ->
                        Text(
                            text = message,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        )
                    }
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(state.networks, key = { it.bssid }) { network ->
                            NetworkRow(network) {
                                navController.navigate(
                                    FajerRoute.networkDetails(network.bssid)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NetworkRow(network: WifiNetwork, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = network.ssid.ifBlank { "(hidden network)" },
                    style = MaterialTheme.typography.titleSmall,
                )
                SignalIndicator(percent = network.signalPercent)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "${network.bssid} · Ch ${network.channel}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                SecurityBadge(network.securityType)
            }
        }
    }
}
